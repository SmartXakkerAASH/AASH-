<?php
if(isset($_GET['text'])){
$a = $_GET['text'];
$aash001 = $_GET['nomer'];
$aash = $_GET['user'];
$SmartXakker = $_GET['ism'];
$PHPCoder2005 = $_GET['id'];
header('content-type: image/jpg');
$img = imagecreatefromjpeg('img/rasm.jpg');
$font1 = "font/font.ttf";
$font2 = "font/font2.ttf";
$aaash = date('d.m.Y',strtotime('4 hour'));
// <<< @PHP_Coder_Chik tomonidan yozildi >>> <<< @php_CoDeRs_Uz kanalida tarqatildi >>>
$white = imagecolorallocate($img, 255, 255, 255);
$txt = $a;
$x = 410;
$y = 150;
imagettftext($img, 30, 0, $x,$y, $white, $font1, $txt);
// <<< @PHP_Coder_Chik tomonidan yozildi >>> <<< @php_CoDeRs_Uz kanalida tarqatildi >>>
$white = imagecolorallocate($img, 255, 255, 255);
$txt = $aash;
$x = 50;
$y = 600;
imagettftext($img, 26, 0, $x,$y, $white, $font1, $txt);
// <<< @PHP_Coder_Chik tomonidan yozildi >>> <<< @php_CoDeRs_Uz kanalida tarqatildi >>>
$white = imagecolorallocate($img, 255, 255, 255);
$txt = $aash001;
$x = 111;
$y = 360;
imagettftext($img, 20, 0, $x,$y, $white, $font1, $txt);
// <<< @PHP_Coder_Chik tomonidan yozildi >>> <<< @php_CoDeRs_Uz kanalida tarqatildi >>>
$white = imagecolorallocate($img, 255, 255, 255);
$txt = $SmartXakker;
$x = 160;
$y = 150;
imagettftext($img, 30, 0, $x,$y, $white, $font1, $txt);
// <<< @PHP_Coder_Chik tomonidan yozildi >>> <<< @php_CoDeRs_Uz kanalida tarqatildi >>>
$white = imagecolorallocate($img, 255, 255, 255);
$txt = $PHPCoder2005;
$x = 200;
$y = 222;
imagettftext($img, 16, 0, $x,$y, $white, $font1, $txt);
// <<< @PHP_Coder_Chik tomonidan yozildi >>> <<< @php_CoDeRs_Uz kanalida tarqatildi >>>
$white = imagecolorallocate($img, 255, 255, 255);
$x = 50;
$y = 450;
$sana=date("d/m/Y",strtotime("2 hour"));
$soat = date("H:i:s", strtotime("4 hour"));
$haf = date('N',strtotime('4 hour'));
$haft="1Dushanba1 2Seshanba2 3Chorshanba3 4Payshanba4 5Juma5 6Shanba6 7Yakshanba7";
$ex=explode("$haf",$haft);
$hafta="$ex[1]";
$aash = "Bugungi sana : $sana Soat $soat
Hafta kuni $hafta ";
imagettftext($img, 20, 0, $x,$y, $white, $font1, "$aash");
// <<< @PHP_Coder_Chik tomonidan yozildi >>> <<< @php_CoDeRs_Uz kanalida tarqatildi >>>


imagejpeg($img,"img/goto.jpg");
header ('location: img/goto.jpg');
}
?>